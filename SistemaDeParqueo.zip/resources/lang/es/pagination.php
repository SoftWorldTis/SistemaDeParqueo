<?php

return [
    'next'     => 'Siguiente &raquo;',
    'previous' => '&laquo; Anterior',
];
