<!DOCTYPE html>
<html>
<head>
    <title>Correo de factura</title>
</head>
<body>
    <h1>Factura adjunta</h1>
    <p>Adjuntamos la factura en formato PDF. Gracias por su compra.</p>
</body>
</html>