<!DOCTYPE html>
<html>
<head>
    <title>{{ $titulo}}</title>
</head>
<body>
    <h1>{{ $titulo }}</h1>
    <p>{{ $contenido }}</p>
</body>
</html>