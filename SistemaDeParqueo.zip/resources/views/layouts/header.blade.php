<nav>
    <div class="nav2" id="nav2">
        <img src="{{asset('/dash/assets/user2 2.png')}}"  class="logoUsuario" alt="">
        <div class="textoNav" id="textoNav">
            <p class="textB">BIENVENIDO,</p>
            <p>AL SISTEMA DE PARKING</p>
        </div>

    </div>
</nav> 
    
