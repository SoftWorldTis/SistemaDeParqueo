@extends('layouts.menu2')



@section('css')
<link rel="stylesheet" href="{{asset('/dash/css/reportes.css')}}" >
@endsection

@section('contenido')
<div class="imagenf">
    <img src="{{asset('/dash/assets/autoparqueo.png')}}" class="icona" alt="">
</div>

<br>
<div class="textoNav" id="textoNav">
    <p class="textB">BIENVENIDO,</p> 
    <br>
    <p class="textB">AL SISTEMA DE PARKING</p>
</div>

</div>

@endsection

