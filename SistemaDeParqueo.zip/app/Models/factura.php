<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class factura extends Model
{
    use HasFactory;
    protected $table='factura';
    protected $primaryKey='facturaid';
    public $timestamps=false;

    public function alquiler()
    {
        return $this->belongsTo(alquiler::class, 'alquilerid');
    }
}
